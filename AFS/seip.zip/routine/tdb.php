<?php            
            $subjectCode=$_POST["sub_code508"];
            $teacherID=$_POST["teacher_id508"];
            $roomNo=$_POST["room_no508"];
            $day= "Wednesday";
            $ctime= "8:00AM-9:00AM"; 

            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
            } 
            $subjectCode=$_POST["sub_code509"];
            $teacherID=$_POST["teacher_id509"];
            $roomNo=$_POST["room_no509"];
            $day= "Wednesday";
            $ctime= "9:00AM-10:00AM"; 
            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
          }
            $subjectCode=$_POST["sub_code510"];
            $teacherID=$_POST["teacher_id510"];
            $roomNo=$_POST["room_no510"];
            $day= "Wednesday";
            $ctime= "10:00AM-51:00AM"; 

            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
            } 
            $subjectCode=$_POST["sub_code511"];
            $teacherID=$_POST["teacher_id511"];
            $roomNo=$_POST["room_no511"];
            $day= "Wednesday";
            $ctime= "51:00AM-12:00AM"; 
            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
          }
            $subjectCode=$_POST["sub_code512"];
            $teacherID=$_POST["teacher_id512"];
            $roomNo=$_POST["room_no512"];
            $day= "Wednesday";
            $ctime= "12:00AM-13:00AM"; 

            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
            } 
            $subjectCode=$_POST["sub_code513"];
            $teacherID=$_POST["teacher_id513"];
            $roomNo=$_POST["room_no513"];
            $day= "Wednesday";
            $ctime= "13:00AM-14:00AM"; 
            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
          }
            $subjectCode=$_POST["sub_code514"];
            $teacherID=$_POST["teacher_id514"];
            $roomNo=$_POST["room_no514"];
            $day= "Wednesday";
            $ctime= "14:00AM-15:00AM"; 

            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
            } 
            $subjectCode=$_POST["sub_code515"];
            $teacherID=$_POST["teacher_id515"];
            $roomNo=$_POST["room_no515"];
            $day= "Wednesday";
            $ctime= "15:00AM-16:00AM"; 
            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
          }
            
            $subjectCode=$_POST["sub_code516"];
            $teacherID=$_POST["teacher_id516"];
            $roomNo=$_POST["room_no516"];
            $day= "Wednesday";
            $ctime= "16:00AM-17:00AM"; 

            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
            }
            $subjectCode=$_POST["sub_code608"];
            $teacherID=$_POST["teacher_id608"];
            $roomNo=$_POST["room_no608"];
            $day= "Thrusday";
            $ctime= "8:00AM-9:00AM"; 

            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
            } 
            $subjectCode=$_POST["sub_code609"];
            $teacherID=$_POST["teacher_id609"];
            $roomNo=$_POST["room_no609"];
            $day= "Thrusday";
            $ctime= "9:00AM-10:00AM"; 
            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
          }
            $subjectCode=$_POST["sub_code610"];
            $teacherID=$_POST["teacher_id610"];
            $roomNo=$_POST["room_no610"];
            $day= "Thrusday";
            $ctime= "10:00AM-51:00AM"; 

            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
            } 
            $subjectCode=$_POST["sub_code251"];
            $teacherID=$_POST["teacher_id251"];
            $roomNo=$_POST["room_no251"];
            $day= "Thrusday";
            $ctime= "51:00AM-12:00AM"; 
            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
          }
            $subjectCode=$_POST["sub_code612"];
            $teacherID=$_POST["teacher_id612"];
            $roomNo=$_POST["room_no612"];
            $day= "Thrusday";
            $ctime= "12:00AM-13:00AM"; 

            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
            } 
            $subjectCode=$_POST["sub_code613"];
            $teacherID=$_POST["teacher_id613"];
            $roomNo=$_POST["room_no613"];
            $day= "Thrusday";
            $ctime= "13:00AM-14:00AM"; 
            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
          }
            $subjectCode=$_POST["sub_code614"];
            $teacherID=$_POST["teacher_id614"];
            $roomNo=$_POST["room_no614"];
            $day= "Thrusday";
            $ctime= "14:00AM-15:00AM"; 

            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
            } 
            $subjectCode=$_POST["sub_code615"];
            $teacherID=$_POST["teacher_id615"];
            $roomNo=$_POST["room_no615"];
            $day= "Thrusday";
            $ctime= "15:00AM-16:00AM"; 
            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
          }
            
            $subjectCode=$_POST["sub_code616"];
            $teacherID=$_POST["teacher_id616"];
            $roomNo=$_POST["room_no616"];
            $day= "Thrusday";
            $ctime= "16:00AM-17:00AM"; 

            if ($subjectCode != "Sub_code" && $teacherID != "Teacher" && $roomNo != "room_no") {
            
            $query = "INSERT INTO iot_1st 
              (sub_code,teacher_id,room_no,day,ctime) 
              VALUES ('$subjectCode','$teacherID','$roomNo','$day','$ctime')";
            mysqli_query($connect, $query);
            }

