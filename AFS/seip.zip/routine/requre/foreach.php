                    <?php
                      $sub_code608 = "IOT-611";
                      $Teacher_name608 = "Teacher Name";
                      $room_No608 = "Room 303";
                      $sub_code609 = "IOT-611";
                      $Teacher_name609 = "Teacher Name";
                      $room_No609 = "Room 303";
                      $sub_code610 = "IOT-611";
                      $Teacher_name610 = "Teacher Name";
                      $room_No610 = "Room 303";
                      $sub_code611 = "IOT-611";
                      $Teacher_name611 = "Teacher Name";
                      $room_No611 = "Room 303";
                      $sub_code612 = "IOT-611";
                      $Teacher_name612 = "Teacher Name";
                      $room_No612 = "Room 303";
                      $sub_code613 = "IOT-611";
                      $Teacher_name613 = "Teacher Name";
                      $room_No613 = "Room 303";
                      $sub_code614 = "IOT-611";
                      $Teacher_name614 = "Teacher Name";
                      $room_No614 = "Room 303";
                      $sub_code615 = "IOT-611";
                      $Teacher_name615 = "Teacher Name";
                      $room_No615 = "Room 303";
                      $sub_code616 = "IOT-611";
                      $Teacher_name616 = "Teacher Name";
                      $room_No616 = "Room 303";

                      ?>
                      <th scope="col"><?php echo $sub_code508."<br> ".$Teacher_name508."<br> ".$room_No508; ?></th>
                      <th scope="col"><?php echo $sub_code509."<br> ".$Teacher_name509."<br> ".$room_No509; ?></th>
                      <th scope="col"><?php echo $sub_code610."<br> ".$Teacher_name610."<br> ".$room_No610; ?></th>
                      <th scope="col"><?php echo $sub_code611."<br> ".$Teacher_name611."<br> ".$room_No611; ?></th>
                      <th scope="col"><?php echo $sub_code612."<br> ".$Teacher_name612."<br> ".$room_No612; ?></th>
                      <th scope="col"><?php echo $sub_code613."<br> ".$Teacher_name613."<br> ".$room_No613; ?></th>
                      <th scope="col"><?php echo $sub_code614."<br> ".$Teacher_name614."<br> ".$room_No614; ?></th>
                      <th scope="col"><?php echo $sub_code615."<br> ".$Teacher_name615."<br> ".$room_No615; ?></th>
                      <th scope="col"><?php echo $sub_code616."<br> ".$Teacher_name616."<br> ".$room_No616; ?></th>
                    </tr>