<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Models\Batch;
use App\Models\Module;
use App\Models\ModuleWiseCourse;
use App\Models\Subject;
use Illuminate\Http\Request;

class ModuleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $moduleList = Module::get();
        $batchList = Batch::get();
        $subjectList = Subject::get();
        return view('pages.module.index', compact('moduleList', 'batchList', 'subjectList'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request);
        $module = new Module();
        $module->name = $request->module_name;
        $module->tranche = $request->tranche;
        $module->batch_id = $request->batch;
        $module->month = $request->month;
        $module->save();


        // $i = 0;
        for ($i = 0; $i < sizeof($request->subject); $i++) {
            $subject = new ModuleWiseCourse();
            $subject->module_id = $module->id;
            $subject->subject_id = $request->subject[$i];
            $subject->save();
        }
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $module = Module::find($id);
        $module->name = $request->module_name;
        $module->subject_id = $request->subject_id;
        $module->remarks = $request->module_description;
        $module->save();
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        $module = Module::find($id);
        if (!is_null($module)) {
            foreach ($module->subjects as $subject) {
                $subject->delete();
            }
            $module->delete();
        }
        return back();
    }
}
