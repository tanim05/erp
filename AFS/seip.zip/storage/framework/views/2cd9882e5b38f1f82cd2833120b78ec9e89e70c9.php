<?php $__env->startSection('styles'); ?>
    <style>
        dashboard-content-one {
            overflow: hidden;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Breadcubs Area Start Here -->
    
    <div class="col-lg-12">
        <p>
            <a href="<?php echo e(route('home')); ?>" title="Home">Home</a> /
            <a href="<?php echo e(route('intake.index')); ?>" title="Intake">Intake</a>
        </p>


        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">List of Intakes
                    <a href="index.php?view=add" class="btn btn-primary" data-toggle="modal" data-target="#standard-modal">
                        <i class="fa fa-plus-circle fw-fa"></i> New
                    </a>
                </h1>
                
                
                <!-- Modal -->
                <div class="modal fade" id="standard-modal" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Add New Intake</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="<?php echo e(route('intake.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <label for="name">Intake Name</label>
                                        <input type="text" id="name" class="form-control mb-3" placeholder="Intake 01"
                                            name="intake_name">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="footer-btn bg-linkedin"> Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>

        <table id="example" class="table table-bordered table-hover" cellspacing="0" style="font-size:12px">

            <thead>
                <tr>
                    <th>Intake Id</th>
                    <th>Intake Name</th>
                    <th width="20%">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $intakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index + 1); ?></td>
                        <td><?php echo e($intake->name); ?></td>
                        <td>
                            
                            <div class="nav">
                                <a title="Edit" href="" class="btn btn-primary btn-xs nav-link mr-3" data-toggle="modal"
                                    data-target="#edit-modal<?php echo e($intake->id); ?>">Edit</a>

                                <!-- Edit Modal -->
                                <div class="modal fade" id="edit-modal<?php echo e($intake->id); ?>" tabindex="-1" role="dialog"
                                    aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Edit Intake Information</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <form action="<?php echo e(route('intake.update', $intake->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group">
                                                    <div class="col-md-12">
                                                        <label for="name">Intake Name</label>
                                                        <input type="text" id="name" class="form-control" placeholder="Name"
                                                            name="intake_name" value="<?php echo e($intake->name); ?>">
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" class="footer-btn bg-linkedin"> Update</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex flex-row ">
                                    <div>
                                        <a title="Edit" href="" class="btn btn-danger btn-xs nav-link " data-toggle="modal"
                                            data-target="#delete-modal<?php echo e($intake->id); ?>">Delete</a>
                                    </div>
                                    <!-- delete Modal -->
                                    <div class="modal fade" id="delete-modal<?php echo e($intake->id); ?>" tabindex="-1"
                                        role="dialog" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Are You Sure</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <form action="<?php echo e(route('intake.delete', $intake->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="footer-btn btn btn-danger">
                                                            Delete</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\seip\resources\views/pages/intake/index.blade.php ENDPATH**/ ?>