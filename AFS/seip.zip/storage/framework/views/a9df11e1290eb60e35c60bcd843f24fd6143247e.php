<?php $__env->startSection('content'); ?>
    <div class="col-lg-12">
        <p>
            <a href="<?php echo e(route('home')); ?>" title="Home">Home</a> /
            <a href="<?php echo e(route('mark.index')); ?>" title="Mark">Mark</a>
        </p>


        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">List of mark
                    <a href=# class="btn btn-primary" data-toggle="modal" data-target="#standard-modal">
                        <i class="fa fa-plus-circle fw-fa"></i> New
                    </a>
                </h1>
                
                
                <!-- Modal -->
                <div class="modal fade" id="standard-modal" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Add New mark</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="<?php echo e(route('mark.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-groupt">
                                    <div class="col-md-6">
                                        <label for="name">Module</label>
                                        <input type="text" id="mark_description" class="form-control mb-3"
                                            name="mark_description">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="name">mark Code</label>
                                        <input type="text" id="mark_code" class="form-control mb-3" placeholder="BC 501"
                                            name="mark_code">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="name">mark Name</label>
                                        <input type="text" id="name" class="form-control mb-3"
                                            placeholder="Business Communication" name="mark_name">
                                    </div>


                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="footer-btn bg-linkedin"> Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>

        <table id="example" class="table table-bordered table-hover" cellspacing="0" style="font-size:12px">

            <thead>
                <tr>
                    
                    <th>Module</th>
                    <th>mark Code</th>
                    <th>mark Name</th>

                    
                    <th width="15%">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td><?php echo e($mark->description); ?></td>
                        <td><?php echo e($mark->code); ?></td>
                        <td><?php echo e($mark->name); ?></td>
                        <td> <a title="Edit" href="" class="btn btn-primary btn-xs" data-toggle="modal"
                                data-target="#edit-modal<?php echo e($mark->id); ?>">Edit</a>

                            <!-- Edit Modal -->
                            <div class="modal fade" id="edit-modal<?php echo e($mark->id); ?>" tabindex="-1" role="dialog"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit mark Information</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <form action="<?php echo e(route('mark.update', $mark->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="col-md-6">
                                                <label for="name">Module</label>
                                                <input type="text" id="mark_description" class="form-control"
                                                    placeholder="Description" name="mark_description"
                                                    value="<?php echo e($mark->description); ?>">
                                            </div>
                                            <div class="col-md-6">
                                                <label for="name">mark Code</label>
                                                <input type="text" id="mark_code" class="form-control"
                                                    placeholder="Description" name="mark_code"
                                                    value="<?php echo e($mark->code); ?>">
                                            </div>
                                            <div class="form-group">
                                                <div class="col-md-6">
                                                    <label for="name">mark Name</label>
                                                    <input type="text" id="name" class="form-control" placeholder="Name"
                                                        name="mark_name" value="<?php echo e($mark->name); ?>">
                                                </div>


                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="footer-btn bg-linkedin"> Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <a title="Delete" href="" class="btn btn-danger btn-xs" data-toggle="modal"
                                data-target="#delete-modal<?php echo e($mark->id); ?>">Delete</a>

                            <!-- delete Modal -->
                            <div class="modal fade" id="delete-modal<?php echo e($mark->id); ?>" tabindex="-1" role="dialog"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Are You Sure</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <form action="<?php echo e(route('mark.delete', $mark->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-footer">
                                                <button type="submit" class="footer-btn btn btn-danger"> Delete</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\seip\resources\views/pages/mark/index.blade.php ENDPATH**/ ?>