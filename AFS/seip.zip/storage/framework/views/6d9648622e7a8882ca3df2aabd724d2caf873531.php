<?php $__env->startSection('content'); ?>
    <!-- Breadcubs Area Start Here -->
    
    <div class="col-lg-12">
        <p>
            <a href="<?php echo e(route('home')); ?>" title="Home">Home</a> /
            <a href="<?php echo e(route('module.index')); ?>" title="Course">module</a>
        </p>


        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">List of Module
                    <a href=# class="btn btn-primary" data-toggle="modal" data-target="#standard-modal">
                        <i class="fa fa-plus-circle fw-fa"></i> New
                    </a>
                </h1>
                <!-- Modal -->
                <div class="modal fade" id="standard-modal" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Add New Module</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="<?php echo e(route('module.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <label for="name">Module Code</label>
                                        <input type="text" id="name" class="form-control mb-3" placeholder="Name"
                                            name="module_name">
                                    </div>
                                    <div class="col-md-12">
                                        <label for="name">Batch Name</label>
                                        
                                        <select name="batch" id="" class="form-control">
                                            <option value="">Select One</option>
                                            <?php $__currentLoopData = $batchList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($batch->id); ?>"><?php echo e($batch->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-12">
                                        <label for="name">Course</label>
                                        
                                        <select name="subject[]" class="form-control select2" multiple="multiple">
                                            <option value="">Select One</option>
                                            <?php $__currentLoopData = $subjectList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-12">
                                        <label for="month">Month</label>
                                        <input type="text" id="month" class="form-control mb-3" placeholder="Description"
                                            name="month">
                                    </div>
                                    <div class="col-md-12">
                                        <label for="tranche">Tranche</label>
                                        <input type="text" id="tranche" class="form-control mb-3" placeholder="tranche"
                                            name="tranche">
                                    </div>
                                    


                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="footer-btn bg-linkedin"> Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>

        <table id="example" class="table table-bordered table-hover" cellspacing="0" style="font-size:12px">

            <thead>
                <tr>
                    
                    <th>Module Code</th>
                    <th>Batch</th>
                    <th>Courses</th>
                    <th>Month</th>
                    <th>Tranche</th>
                    <th width="15%">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $moduleList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td><?php echo e($module->name); ?></td>
                        <td><?php echo e($module->batch->name); ?></td>
                        <td>
                            <?php $__currentLoopData = $module->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($loop->index + 1); ?> . <?php echo e($subject->subject->name); ?> <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($module->month); ?></td>
                        <td><?php echo e($module->tranche); ?></td>
                        <td> <a title="Edit" href="" class="btn btn-primary btn-xs" data-toggle="modal"
                                data-target="#edit-modal<?php echo e($module->id); ?>">Edit</a>

                            <!-- Edit Modal -->
                            <div class="modal fade" id="edit-modal<?php echo e($module->id); ?>" tabindex="-1" role="dialog"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit module Information</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <form action="<?php echo e(route('module.update', $module->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <div class="col-md-12">
                                                    <label for="name">Module Code</label>
                                                    <input type="text" id="name" class="form-control mb-3"
                                                        placeholder="Name" name="module_name"
                                                        value="<?php echo e($module->name); ?>">
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="name">Batch Name</label>
                                                    
                                                    <select name="batch" id="" class="form-control">
                                                        <option value="">Select One</option>
                                                        <?php $__currentLoopData = $batchList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($batch->id); ?>"><?php echo e($batch->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="name">Course</label>
                                                    
                                                    <select name="subject[]" id="" class="form-control select2"
                                                        multiple="multiple">
                                                        <option value="">Select One</option>
                                                        <?php $__currentLoopData = $subjectList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="month">Month</label>
                                                    <input type="text" id="month" class="form-control mb-3"
                                                        placeholder="Description" name="month"
                                                        value="<?php echo e($module->month); ?>">
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="tranche">Tranche</label>
                                                    <input type="text" id="tranche" class="form-control mb-3"
                                                        placeholder="tranche" name="tranche"
                                                        value="<?php echo e($module->tranche); ?>">
                                                </div>
                                                


                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="footer-btn bg-linkedin"> Save</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <a title="Delete" href="" class="btn btn-danger btn-xs" data-toggle="modal"
                                data-target="#delete-modal<?php echo e($module->id); ?>">Delete</a>

                            <!-- delete Modal -->
                            <div class="modal fade" id="delete-modal<?php echo e($module->id); ?>" tabindex="-1" role="dialog"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Are You Sure</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <form action="<?php echo e(route('module.delete', $module->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-footer">
                                                <button type="submit" class="footer-btn btn btn-danger"> Delete</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $('.select2').select2();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\seip\resources\views/pages/module/index.blade.php ENDPATH**/ ?>