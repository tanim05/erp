<!-- jquery-->
<script src="<?php echo e(asset('theme/js/jquery-3.3.1.min.js')); ?>"></script>
<!-- Plugins js -->
<script src="<?php echo e(asset('theme/js/plugins.js')); ?>"></script>
<!-- Popper js -->
<script src="<?php echo e(asset('theme/js/popper.min.js')); ?>"></script>
<!-- Bootstrap js -->
<script src="<?php echo e(asset('theme/js/bootstrap.min.js')); ?>"></script>
<!-- Counterup Js -->
<script src="<?php echo e(asset('theme/js/jquery.counterup.min.js')); ?>"></script>
<!-- Moment Js -->
<script src="<?php echo e(asset('theme/js/moment.min.js')); ?>"></script>
<!-- Waypoints Js -->
<script src="<?php echo e(asset('theme/js/jquery.waypoints.min.js')); ?>"></script>
<!-- Scroll Up Js -->
<script src="<?php echo e(asset('theme/js/jquery.scrollUp.min.js')); ?>"></script>
<!-- Full Calender Js -->
<script src="<?php echo e(asset('theme/js/fullcalendar.min.js')); ?>"></script>
<!-- Chart Js -->
<script src="<?php echo e(asset('theme/js/Chart.min.js')); ?>"></script>
<!-- Custom Js -->
<script src="<?php echo e(asset('theme/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('theme/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/js/datepicker.min.js')); ?>"></script>
<?php /**PATH D:\xampp\htdocs\laravel\seip\resources\views/layout/scripts.blade.php ENDPATH**/ ?>