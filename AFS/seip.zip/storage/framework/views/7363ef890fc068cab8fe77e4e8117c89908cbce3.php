<!-- Sidebar Area Start Here -->
<div class="sidebar-main sidebar-menu-one sidebar-expand-md sidebar-color">
    <div class="mobile-sidebar-header d-md-none">
        <div class="header-logo">
            <a href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(URL::asset('/image/seip-logo.png')); ?>" alt="seip logo" height="35" width="90">
                <img src="<?php echo e(URL::asset('/image/iba.png')); ?>" alt="du iba logo" height="35" width="90">
            </a>
        </div>
    </div>
    <div class="sidebar-menu-content">
        <ul class="nav nav-sidebar-menu sidebar-toggle-view">
            <li class="nav-item">
                <a href="<?php echo e(route('home')); ?>" class="nav-link"><i
                        class="flaticon-dashboard"></i><span>Dashboard</span></a>
                
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('intake.index')); ?>" class="nav-link"><i
                        class="flaticon-maths-class-materials-cross-of-a-pencil-and-a-ruler"></i><span>Intake</span></a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('batch.index')); ?>" class="nav-link"><i
                        class="flaticon-maths-class-materials-cross-of-a-pencil-and-a-ruler"></i><span>Batch</span></a>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('module.index')); ?>" class="nav-link"><i
                        class="flaticon-open-book"></i><span>Module</span></a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('subject.index')); ?>" class="nav-link"><i
                        class="flaticon-open-book"></i><span>Course</span></a>
            </li>
            
            <li class="nav-item">
                <a href="<?php echo e(route('participant.index')); ?>" class="nav-link"><i
                        class="flaticon-classmates"></i><span>Participants</span></a>
                
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('teacher.index')); ?>" class="nav-link"><i
                        class="flaticon-multiple-users-silhouette"></i><span>Teachers</span></a>
                <ul class="nav sub-group-menu">
                    <li class="nav-item">
                        <a href="all-teacher.html" class="nav-link"><i class="fas fa-angle-right"></i>All
                            Teachers</a>
                    </li>
                    <li class="nav-item">
                        <a href="teacher-details.html" class="nav-link"><i class="fas fa-angle-right"></i>Teacher
                            Details</a>
                    </li>
                    <li class="nav-item">
                        <a href="add-teacher.html" class="nav-link"><i class="fas fa-angle-right"></i>Add
                            Teacher</a>
                    </li>
                    <li class="nav-item">
                        <a href="teacher-payment.html" class="nav-link"><i class="fas fa-angle-right"></i>Payment</a>
                    </li>
                </ul>
            </li>
            <li class="nav-item">
                <a href="http://localhost/laravel/seip/routine/routine.php" class="nav-link"><i
                        class="flaticon-script"></i><span>Routine</span></a>
            </li>
            <li class="nav-item">
                <a href="http://localhost/laravel/seip/attendance/" class="nav-link"><i
                        class="flaticon-checklist"></i><span>Attendence</span></a>
            </li>
            <li class="nav-item ">
                <a href="<?php echo e(route('mark.index')); ?>" class="nav-link"><i
                        class="flaticon-shopping-list"></i><span>Participant Marks</span></a>
                <ul class="nav sub-group-menu">
                    <li class="nav-item">
                        <a href="exam-schedule.html" class="nav-link"><i class="fas fa-angle-right"></i>Exam
                            Schedule</a>
                    </li>
                    <li class="nav-item">
                        <a href="exam-grade.html" class="nav-link"><i class="fas fa-angle-right"></i>Exam
                            Grades</a>
                    </li>
                </ul>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('notice.index')); ?>" class="nav-link"><i
                        class="flaticon-chat"></i><span>Notice</span></a>
            </li>
            
            
        </ul>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\laravel\seip\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>