<?php $__env->startSection('content'); ?>

    <div class="dashboard-content-one">
        <!-- Breadcubs Area Start Here -->
        <div class="breadcrumbs-area">
            <h3>Notice Board</h3>
            <ul>
                <li>
                    <a href="<?php echo e(route('home')); ?>">Home</a>
                </li>
                <li>Notice</li>
            </ul>
        </div>
        <!-- Breadcubs Area End Here -->
        <div class="row">
            <!-- Add Notice Area Start Here -->
            <div class="col-4-xxxl col-12">
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h3>Create A Notice</h3>
                            </div>
                            
                        </div>
                        <form action="<?php echo e(route('notice.store')); ?>" method="POST" class="new-added-form">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-12-xxxl col-lg-6 col-12 form-group">
                                    <label>Title</label>
                                    <input type="text" name="title" placeholder="" class="form-control">
                                </div>
                                <div class="col-12-xxxl col-lg-6 col-12 form-group">
                                    <label>Details</label>
                                    <textarea style="height: 100px;" class="form-control" name="details"
                                        rows="3"></textarea>
                                </div>
                                
                                <div class="col-12-xxxl col-lg-6 col-12 form-group">
                                    <label>Posted By </label>
                                    <input type="text" placeholder="" name="posted_by" class="form-control">
                                    <i class="fas fa-user"></i>
                                </div>



                                <div class="col-12-xxxl col-lg-6 col-12 form-group">
                                    <label>Date</label>
                                    <input type="text" placeholder="" name="date" class="form-control air-datepicker">
                                    <i class="far fa-calendar-alt"></i>
                                </div>
                                <div class="col-12 form-group mg-t-8">
                                    <button type="submit"
                                        class="btn-fill-lg btn-gradient-yellow btn-hover-bluedark">Save</button>
                                    <button type="reset" class="btn-fill-lg bg-blue-dark btn-hover-yellow">Reset</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Add Notice Area End Here -->
            <!-- All Notice Area Start Here -->
            <div class="col-8-xxxl col-12">
                <div class="card height-auto">
                    <div class="card-body">
                        <div class="heading-layout1">
                            <div class="item-title">
                                <h3>Notice Board</h3>
                            </div>
                            
                        </div>
                        <form class="mg-b-20">
                            <div class="row gutters-8">
                                <div class="col-lg-5 col-12 form-group">
                                    <input type="text" placeholder="Search by Date ..." class="form-control">
                                </div>
                                <div class="col-lg-5 col-12 form-group">
                                    <input type="text" placeholder="Search by Title ..." class="form-control">
                                </div>
                                <div class="col-lg-2 col-12 form-group">
                                    <button type="submit" class="fw-btn-fill btn-gradient-yellow">SEARCH</button>
                                </div>
                            </div>
                        </form>
                        <div class="notice-board-wrap">

                            

                            <?php $__currentLoopData = $noticeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="notice-list">
                                    <div class="post-date bg-yellow"><?php echo e($notice->date); ?></div>
                                    <h6 class="notice-title">
                                        <a href="#">
                                            <?php echo e($notice->title); ?><br>
                                            <?php echo e($notice->details); ?>

                                        </a>
                                    </h6>
                                    <div class="entry-meta"> <?php echo e($notice->posted_by); ?> </div>
                                    <div class="float-right">
                                        <a href="<?php echo e(route('notice.delete', $notice->id)); ?>">
                                            <div class="badge badge-info">
                                                <span>Delete</span>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\seip\resources\views/pages/notice/index.blade.php ENDPATH**/ ?>