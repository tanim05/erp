<!-- Footer Area Start Here -->
<footer class="d-flex justify-content-center">
    <div class="copyright">© Copyrights <a href="#">SEIP-IBA, </a> 2021. All rights reserved.</div>
</footer>
<!-- Footer Area End Here -->
<?php /**PATH D:\xampp\htdocs\laravel\seip\resources\views/layout/footer.blade.php ENDPATH**/ ?>