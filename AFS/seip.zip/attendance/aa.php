<section class="promotion">
        <div class="container">
                            <div class="row">
                    <div class="col-lg-12 sectiontitle">
                        
                                <h1>our products</h1>

                                            </div>
                </div>

                        <div class="row">
                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <figure class="medic-effect">
                            <img width="555" height="355" src="https://a.purabigi.com/wp-content/uploads/2020/04/Fire-Insurance-555x355.png" class="attachment-medical-head-about-image size-medical-head-about-image wp-post-image" alt="">                            <figcaption>
                                <div>
                                    <h2>
                                        <a href="https://a.purabigi.com/fire-insurance-3/">
                                            Fire Insurance                                        </a>
                                    </h2>
                                </div>
                            </figcaption>
                        </figure>
                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <figure class="medic-effect">
                            <img width="555" height="358" src="https://a.purabigi.com/wp-content/uploads/2020/04/marine-insurance.jpg" class="attachment-medical-head-about-image size-medical-head-about-image wp-post-image" alt="">                            <figcaption>
                                <div>
                                    <h2>
                                        <a href="https://a.purabigi.com/marine-insurance-2/">
                                            Marine Insurance                                        </a>
                                    </h2>
                                </div>
                            </figcaption>
                        </figure>
                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <figure class="medic-effect">
                            <img width="555" height="358" src="https://a.purabigi.com/wp-content/uploads/2020/01/How-To-Find-Affordable-Car-Insurance-Policies-Effortlessly-680x365_c-555x365.jpg" class="attachment-medical-head-about-image size-medical-head-about-image wp-post-image" alt="">                            <figcaption>
                                <div>
                                    <h2>
                                        <a href="https://a.purabigi.com/motor-insurance/">
                                            Motor Insurance                                        </a>
                                    </h2>
                                </div>
                            </figcaption>
                        </figure>
                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <figure class="medic-effect">
                            <img width="555" height="460" src="https://a.purabigi.com/wp-content/uploads/2020/03/engineering-banner-555x460.jpg" class="attachment-medical-head-about-image size-medical-head-about-image wp-post-image" alt="">                            <figcaption>
                                <div>
                                    <h2>
                                        <a href="https://a.purabigi.com/engineering-insurance-2/">
                                            Engineering Insurance                                        </a>
                                    </h2>
                                </div>
                            </figcaption>
                        </figure>
                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <figure class="medic-effect">
                            <img width="555" height="427" src="https://a.purabigi.com/wp-content/uploads/2020/03/MISCELLANEOUS-ACCIDENT-INSURANCE-555x427.jpg" class="attachment-medical-head-about-image size-medical-head-about-image wp-post-image" alt="">                            <figcaption>
                                <div>
                                    <h2>
                                        <a href="https://a.purabigi.com/miscellaneous-accident-insurance-3/">
                                            Miscellaneous Accident Insurance                                        </a>
                                    </h2>
                                </div>
                            </figcaption>
                        </figure>
                    </div>
                            </div>
    </div></section>
<section class="about-us">
<div class="container">
<div class="row">
<div class="col-lg-6 col-md-6 col-sm-12">
<figure><img src="https://a.purabigi.com/wp-content/uploads/2020/01/cropped-insurance-services-concept-flat-icons-poster-web-site-advertising-like-house-car-medical-travel-69390539-e1579799508815.jpg"></figure>
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
<h2><a href="https://a.purabigi.com/about-us-2/"><br>About Us </a></h2>
<p class="has-drop-cap has-text-align-left has-normal-font-size">City General Insurance Company Limited is one of the leading Non-life insurance company engaged in general insurance business since 1996. The company incorporated under the companies Act 1994 and obtained its certificate of registration from the than controller of Insurance, Government of the People’s Republic of Bangladesh. The company is engaged various types of Non-life insurance business and it has automatic reinsurance arrangement, i.e. Treaty Agreement for all classes of insurance with Reinsurer. We ensure prompt settlement of all types of claim with utmost satisfaction of the insured within the shortest possible time. CRISL upgraded the company at AA- with a “Stable Outlook”.</p>
</div>
</div>
<p><!-- row --></p>
</div>
</section>
<section class="services">
<div class="container">
<div class="row">
<div class="col-lg-12 sectiontitle">
<h2>News and Events</h2>
</div>
</div>
<div class="row">
<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
<div class="box">
<figure><a href="https://a.purabigi.com/annual-conference-2020/"><br><img class="attachment-medical-head-about-image size-medical-head-about-image wp-post-image" src="https://a.purabigi.com/wp-content/uploads/2020/02/Banner_2-2-555x460.jpg" alt="" width="555" height="460"></a></figure>
<div class="description">
<h3><a href="https://a.purabigi.com/annual-conference-2020/">Annual Conference 2020</a></h3>
</div>
</div>
</div>
<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
<div class="box">
<figure><a href="https://a.purabigi.com/24th-meeting/"><br><img class="attachment-medical-head-about-image size-medical-head-about-image wp-post-image" src="https://a.purabigi.com/wp-content/uploads/2020/01/25th-Annual-General-meeting-820x450.png" alt="" width="555" height="460"></a></figure>
<div class="description">
<h3><a href="https://a.purabigi.com/24th-meeting/">25th Annual General Meeting</a></h3>

</div>
</div>
</div>
<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
<div class="box">
<figure><a href="https://a.purabigi.com/bima-mela-2/"><br><img class="attachment-medical-head-about-image size-medical-head-about-image wp-post-image" src="https://a.purabigi.com/wp-content/uploads/2020/02/Bima-Mela-555x460.jpg" alt="" width="555" height="460"></a></figure>
<div class="description">
<h3><a href="https://a.purabigi.com/bima-mela-2/">Bima Mela</a></h3>
</div>
</div>
</div>
</div>
</div>
</section>
<div class="online-main">
<div class="container">
<div class="row">
<div class="col-sm-4 online">
<div class="online-inner">
<div class="online-image">
<p><img class="img-responsive" src="https://a.purabigi.com/wp-content/uploads/2020/04/online-insurance-claim-e1586522131694.jpg" alt=""></p>
<div class="online-head">ONLINE CLAIM</div>
</div>
<div class="online-body">Fill up the form &amp;<br><a href="https://a.purabigi.com/online-claim/">SEND</a> Us Claim Information</div>
</div>
</div>
<div class="col-sm-4 online">
<div class="online-inner">
<div class="online-image">
<p><img class="img-responsive" src="https://a.purabigi.com/wp-content/uploads/2020/04/images.jpg" alt=""></p>
<div class="online-head">ONLINE QUERY</div>
</div>
<div class="online-body">Choose a product<br><select id="test_ChoiseService" class="form-control" name="ChoiseService" onchange="loadForm(this)">
<option value="MBDInsurance">Motor Insurance</option>
<option value="CPMInsurance">Act Liability</option>
<option value="BPVEInsurance">Comprehensive</option>
<option value="CARInsurance">Overseas Mediclaim Policy</option>
<option value="EARInsurance">Fire Declaration form</option>
<option value="EEIInsurance">Marine Declaration Form</option>
<option value="AVIATIONInsurance">KYC Form</option>
</select></div>
</div>
</div>
<div class="col-sm-4 online">
<div class="online-inner">
<div class="online-image">
<p><img class="img-responsive" src="https://a.purabigi.com/wp-content/uploads/2020/04/196583-636879893691941407-16x9-1.jpg" alt=""></p>
<div class="online-head">CGIC’s SHARE INFORMATION</div>
</div>
<div class="online-body stock">
<ul class="list-inline">
<li><a href="http://www.dsebd.org/displayCompany.php?name=CITYGENINS" target="_blank" rel="noopener noreferrer"><img class="img-responsive" src="http://pragatiinsurance.com/assets/site/img/dhaka.png" alt=""></a></li>
<li><a href="https://www.cse.com.bd/company/companydetails/CITYGENINS" target="_blank" rel="noopener noreferrer"><img class="img-responsive" src="http://pragatiinsurance.com/assets/site/img/chittagong.png" alt=""></a></li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
<section class="faq">
<div class="container">
<div class="row">
<div class="col-lg-6 col-md-6 col-sm-12 booking_form no-right-padding">
<h2>FaceBook</h2>
<div id="fb-root">&nbsp;</div>
<p><script async="" defer="" crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&amp;version=v6.0"></script></p>
<div class="fb-page" data-href="https://www.facebook.com/pg/cityinsurancebd" data-tabs="timeline" data-width="500" data-height="600" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
<blockquote class="fb-xfbml-parse-ignore" cite="https://www.facebook.com/pg/cityinsurancebd">
<p><a href="https://www.facebook.com/pg/cityinsurancebd">City General Insurance Company Limited</a></p>
</blockquote>
</div>
<div id="wpcf7-f181-o2" class="wpcf7" dir="ltr" lang="en-US" role="form"><form class="wpcf7-form" action="/#wpcf7-f181-o2" method="post" novalidate="novalidate">
<div class="wpcf7-response-output wpcf7-display-none">&nbsp;</div>
</form></div>
</div>
<div class="col-lg-6 col-md-6 col-sm-12 faq_accordance no-left-padding">
<h2>Frequently Asked Questions</h2>
<div class="accordion js-accordion">
<div class="accordion__item js-accordion-item active">
<div class="accordion-header js-accordion-header ">How can i do online Insurance?</div>
<div class="accordion-body js-accordion-body" style="display: block;">
<div class="accordion-body__contents">This is easy and simple. Please click on Online Insurance from the menu. Then fill up the from and read the state and pay the quoted amount and get the certificate by home delivery.</div>
</div>
</div>
<p><!-- end of accordion body --></p>
</div>
<p><!-- end of accordion item --></p>
</div>
<p><!-- end of accordion --></p>
</div>
</div>
</section>
<section>
<div class="container">
<div class="row">
<div class="text-center">
<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/F_qHa2RS4L8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>

</div>
</div>
</div>
</section>


<section class="testimonial">
<div class="container">
<div class="row">
<div class="col-lg-12 sectiontitle">
<h2>What our concern</h2>
</div>
</div>
<div class="row">
<div class="owl-testimonial owl-carousel owl-theme owl-loaded owl-drag"><!-- item --><br><!-- item -->

<div class="owl-stage-outer">
<div class="owl-stage" style="transform: translate3d(-980px, 0px, 0px); transition: all 0s ease 0s; width: 2940px;">
<div class="owl-item cloned" style="width: 480px; margin-right: 10px;">
<div class="item">
<div class="testimonial-wrap">
<div class="box">
<div class="testimonial-image">
<figure><a href="https://a.purabigi.com/message-from-the-chairman/"><br><img class="attachment-thumbnail size-thumbnail wp-post-image" src="https://a.purabigi.com/wp-content/uploads/2020/02/Anwar-Hossain-Sir-150x150.jpg" alt="" width="150" height="150"> </a></figure>
</div>
<div class="testimonial-content">
<p>It is my immense pleasure to inform that City General Insurance Company Limited has launched its newly designed web page with detailed information about the…</p>
</div>
</div>
<h3><a href="https://a.purabigi.com/message-from-the-chairman/"><br>Anwar Hossain </a></h3>
</div>
</div>
</div>
<div class="owl-item cloned" style="width: 480px; margin-right: 10px;">
<div class="item">
<div class="testimonial-wrap">
<div class="box">
<div class="testimonial-image">
<figure><a href="https://a.purabigi.com/message-from-the-ceo/"><br><img class="attachment-thumbnail size-thumbnail wp-post-image" src="https://a.purabigi.com/wp-content/uploads/2020/11/unnamed-150x150.jpg" alt="" width="150" height="150"> </a></figure>
</div>
<div class="testimonial-content">
<p>City General Insurance Company Limited started its operation in 1996 with sole aim of extending quality of service in the insuring community of Bangladesh. The…</p>
</div>
</div>
<h3><a href="https://a.purabigi.com/message-from-the-ceo/"><br>Md. Shamim Hossain </a></h3>
</div>
</div>
</div>
<div class="owl-item active" style="width: 480px; margin-right: 10px;">
<div class="item">
<div class="testimonial-wrap">
<div class="box">
<div class="testimonial-image">
<figure><a href="https://a.purabigi.com/message-from-the-chairman/"><br><img class="attachment-thumbnail size-thumbnail wp-post-image" src="https://a.purabigi.com/wp-content/uploads/2020/02/Anwar-Hossain-Sir-150x150.jpg" alt="" width="150" height="150"> </a></figure>
</div>
<div class="testimonial-content">
<p>It is my immense pleasure to inform that City General Insurance Company Limited has launched its newly designed web page with detailed information about the…</p>
</div>
</div>
<h3><a href="https://a.purabigi.com/message-from-the-chairman/"><br>Anwar Hossain </a></h3>
</div>
</div>
</div>
<div class="owl-item active" style="width: 480px; margin-right: 10px;">
<div class="item">
<div class="testimonial-wrap">
<div class="box">
<div class="testimonial-image">
<figure><a href="https://a.purabigi.com/message-from-the-ceo/"><br><img class="attachment-thumbnail size-thumbnail wp-post-image" src="https://a.purabigi.com/wp-content/uploads/2020/11/unnamed-150x150.jpg" alt="" width="150" height="150"> </a></figure>
</div>
<div class="testimonial-content">
<p>City General Insurance Company Limited started its operation in 1996 with sole aim of extending quality of service in the insuring community of Bangladesh. The…</p>
</div>
</div>
<h3><a href="https://a.purabigi.com/message-from-the-ceo/"><br>Md. Shamim Hossain </a></h3>
</div>
</div>
</div>
<div class="owl-item cloned" style="width: 480px; margin-right: 10px;">
<div class="item">
<div class="testimonial-wrap">
<div class="box">
<div class="testimonial-image">
<figure><a href="https://a.purabigi.com/message-from-the-chairman/"><br><img class="attachment-thumbnail size-thumbnail wp-post-image" src="https://a.purabigi.com/wp-content/uploads/2020/02/Anwar-Hossain-Sir-150x150.jpg" alt="" width="150" height="150"> </a></figure>
</div>
<div class="testimonial-content">
<p>It is my immense pleasure to inform that City General Insurance Company Limited has launched its newly designed web page with detailed information about the…</p>
</div>
</div>
<h3><a href="https://a.purabigi.com/message-from-the-chairman/"><br>Anwar Hossain </a></h3>
</div>
</div>
</div>
<div class="owl-item cloned" style="width: 480px; margin-right: 10px;">
<div class="item">
<div class="testimonial-wrap">
<div class="box">
<div class="testimonial-image">
<figure><a href="https://a.purabigi.com/message-from-the-ceo/"><br><img class="attachment-thumbnail size-thumbnail wp-post-image" src="https://a.purabigi.com/wp-content/uploads/2020/11/unnamed-150x150.jpg" alt="" width="150" height="150"> </a></figure>
</div>
<div class="testimonial-content">
<p>City General Insurance Company Limited started its operation in 1996 with sole aim of extending quality of service in the insuring community of Bangladesh. The…</p>
</div>
</div>
<h3><a href="https://a.purabigi.com/message-from-the-ceo/"><br>Md. Shamim Hossain </a></h3>
</div>
</div>
</div>
</div>
</div>
<div class="owl-nav disabled"><button class="owl-prev" role="presentation" type="button"><span aria-label="Previous">‹</span></button><button class="owl-next" role="presentation" type="button"><span aria-label="Next">›</span></button></div>
<div class="owl-dots disabled">&nbsp;</div>
</div>
</div>
</div>
</section>