@extends('layout.master')
@section('content')
    <!-- Breadcubs Area Start Here -->
    {{-- <div class="breadcrumbs-area">
        <h3>Admin Dashboard</h3>
        <ul>
            <li>
                <a href="{{ route('home') }}">Home</a>
            </li>
            <li>Admin</li>
        </ul>
    </div> --}}
    <div class="col-lg-12">
        <p>
            <a href="{{ route('home') }}" title="Home">Home</a> /
            <a href="{{ route('module.index') }}" title="Course">module</a>
        </p>


        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">List of Module
                    <a href=# class="btn btn-primary" data-toggle="modal" data-target="#standard-modal">
                        <i class="fa fa-plus-circle fw-fa"></i> New
                    </a>
                </h1>
                <!-- Modal -->
                <div class="modal fade" id="standard-modal" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Add New Module</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="{{ route('module.store') }}" method="POST">
                                @csrf
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <label for="name">Module Code</label>
                                        <input type="text" id="name" class="form-control mb-3" placeholder="Name"
                                            name="module_name">
                                    </div>
                                    <div class="col-md-12">
                                        <label for="name">Batch Name</label>
                                        {{-- <input type="text" id="name" class="form-control mb-3" placeholder="Name"
                                            name="module_name"> --}}
                                        <select name="batch" id="" class="form-control">
                                            <option value="">Select One</option>
                                            @foreach ($batchList as $batch)
                                                <option value="{{ $batch->id }}">{{ $batch->name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-md-12">
                                        <label for="name">Course</label>
                                        {{-- <input type="text" id="name" class="form-control mb-3" placeholder="Name"
                                            name="module_name"> --}}
                                        <select name="subject[]" class="form-control select2" multiple="multiple">
                                            <option value="">Select One</option>
                                            @foreach ($subjectList as $subject)
                                                <option value="{{ $subject->id }}">{{ $subject->name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-md-12">
                                        <label for="month">Month</label>
                                        <input type="text" id="month" class="form-control mb-3" placeholder="Description"
                                            name="month">
                                    </div>
                                    <div class="col-md-12">
                                        <label for="tranche">Tranche</label>
                                        <input type="text" id="tranche" class="form-control mb-3" placeholder="tranche"
                                            name="tranche">
                                    </div>
                                    {{-- <div class="col-md-6">
                                        <label for="subject_id">Subject</label>

                                        <select name="subject_id" id="subject_id" class="form-control">
                                            <option value="">Select Subject</option>
                                            @foreach ($subjects as $subject)
                                                <option value="{{ $subject->id }}">{{ $subject->name }}</option>
                                            @endforeach
                                        </select>
                                    </div> --}}


                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="footer-btn bg-linkedin"> Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>

        <table id="example" class="table table-bordered table-hover" cellspacing="0" style="font-size:12px">

            <thead>
                <tr>
                    {{-- <th>Module ID</th>
                    <th>Module Name</th>
                    <th>Description</th>
                    <th>Subject ID</th> --}}
                    <th>Module Code</th>
                    <th>Batch</th>
                    <th>Courses</th>
                    <th>Month</th>
                    <th>Tranche</th>
                    <th width="15%">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($moduleList as $module)
                    <tr>
                        {{-- <td>{{ $loop->index + 1 }}</td> --}}
                        <td>{{ $module->name }}</td>
                        <td>{{ $module->batch->name }}</td>
                        <td>
                            @foreach ($module->subjects as $subject)
                                {{ $loop->index + 1 }} . {{ $subject->subject->name }} <br>
                            @endforeach
                        </td>
                        <td>{{ $module->month }}</td>
                        <td>{{ $module->tranche }}</td>
                        <td> <a title="Edit" href="" class="btn btn-primary btn-xs" data-toggle="modal"
                                data-target="#edit-modal{{ $module->id }}">Edit</a>

                            <!-- Edit Modal -->
                            <div class="modal fade" id="edit-modal{{ $module->id }}" tabindex="-1" role="dialog"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit module Information</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <form action="{{ route('module.update', $module->id) }}" method="POST">
                                            @csrf
                                            <div class="form-group">
                                                <div class="col-md-12">
                                                    <label for="name">Module Code</label>
                                                    <input type="text" id="name" class="form-control mb-3"
                                                        placeholder="Name" name="module_name"
                                                        value="{{ $module->name }}">
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="name">Batch Name</label>
                                                    {{-- <input type="text" id="name" class="form-control mb-3" placeholder="Name"
                                                        name="module_name"> --}}
                                                    <select name="batch" id="" class="form-control">
                                                        <option value="">Select One</option>
                                                        @foreach ($batchList as $batch)
                                                            <option value="{{ $batch->id }}">{{ $batch->name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="name">Course</label>
                                                    {{-- <input type="text" id="name" class="form-control mb-3" placeholder="Name"
                                                        name="module_name"> --}}
                                                    <select name="subject[]" id="" class="form-control select2"
                                                        multiple="multiple">
                                                        <option value="">Select One</option>
                                                        @foreach ($subjectList as $subject)
                                                            <option value="{{ $subject->id }}">{{ $subject->name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="month">Month</label>
                                                    <input type="text" id="month" class="form-control mb-3"
                                                        placeholder="Description" name="month"
                                                        value="{{ $module->month }}">
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="tranche">Tranche</label>
                                                    <input type="text" id="tranche" class="form-control mb-3"
                                                        placeholder="tranche" name="tranche"
                                                        value="{{ $module->tranche }}">
                                                </div>
                                                {{-- <div class="col-md-6">
                                                    <label for="subject_id">Subject</label>

                                                    <select name="subject_id" id="subject_id" class="form-control">
                                                        <option value="">Select Subject</option>
                                                        @foreach ($subjects as $subject)
                                                            <option value="{{ $subject->id }}">{{ $subject->name }}</option>
                                                        @endforeach
                                                    </select>
                                                </div> --}}


                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="footer-btn bg-linkedin"> Save</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <a title="Delete" href="" class="btn btn-danger btn-xs" data-toggle="modal"
                                data-target="#delete-modal{{ $module->id }}">Delete</a>

                            <!-- delete Modal -->
                            <div class="modal fade" id="delete-modal{{ $module->id }}" tabindex="-1" role="dialog"
                                aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Are You Sure</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <form action="{{ route('module.delete', $module->id) }}" method="POST">
                                            @csrf
                                            <div class="modal-footer">
                                                <button type="submit" class="footer-btn btn btn-danger"> Delete</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                @endforeach

            </tbody>

        </table>

    </div>
@endsection
@section('styles')
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
@endsection
@section('scripts')
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $('.select2').select2();
    </script>
@endsection
