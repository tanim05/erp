<!-- jquery-->
<script src="{{ asset('theme/js/jquery-3.3.1.min.js') }}"></script>
<!-- Plugins js -->
<script src="{{ asset('theme/js/plugins.js') }}"></script>
<!-- Popper js -->
<script src="{{ asset('theme/js/popper.min.js') }}"></script>
<!-- Bootstrap js -->
<script src="{{ asset('theme/js/bootstrap.min.js') }}"></script>
<!-- Counterup Js -->
<script src="{{ asset('theme/js/jquery.counterup.min.js') }}"></script>
<!-- Moment Js -->
<script src="{{ asset('theme/js/moment.min.js') }}"></script>
<!-- Waypoints Js -->
<script src="{{ asset('theme/js/jquery.waypoints.min.js') }}"></script>
<!-- Scroll Up Js -->
<script src="{{ asset('theme/js/jquery.scrollUp.min.js') }}"></script>
<!-- Full Calender Js -->
<script src="{{ asset('theme/js/fullcalendar.min.js') }}"></script>
<!-- Chart Js -->
<script src="{{ asset('theme/js/Chart.min.js') }}"></script>
<!-- Custom Js -->
<script src="{{ asset('theme/js/main.js') }}"></script>
<script src="{{ asset('theme/js/select2.min.js') }}"></script>
<script src="{{ asset('theme/js/datepicker.min.js') }}"></script>
