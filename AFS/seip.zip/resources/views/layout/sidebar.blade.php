<!-- Sidebar Area Start Here -->
<div class="sidebar-main sidebar-menu-one sidebar-expand-md sidebar-color">
    <div class="mobile-sidebar-header d-md-none">
        <div class="header-logo">
            <a href="{{ route('home') }}">
                <img src="{{ URL::asset('/image/seip-logo.png') }}" alt="seip logo" height="35" width="90">
                <img src="{{ URL::asset('/image/iba.png') }}" alt="du iba logo" height="35" width="90">
            </a>
        </div>
    </div>
    <div class="sidebar-menu-content">
        <ul class="nav nav-sidebar-menu sidebar-toggle-view">
            <li class="nav-item">
                <a href="{{ route('home') }}" class="nav-link"><i
                        class="flaticon-dashboard"></i><span>Dashboard</span></a>
                {{-- <ul class="nav sub-group-menu">
                    <li class="nav-item">
                        <a href="index.html" class="nav-link"><i class="fas fa-angle-right"></i>Admin</a>
                    </li>
                    <li class="nav-item">
                        <a href="index3.html" class="nav-link"><i class="fas fa-angle-right"></i>Participants</a>
                    </li>
                    <li class="nav-item">
                        <a href="index5.html" class="nav-link"><i class="fas fa-angle-right"></i>Teachers</a>
                    </li>
                </ul> --}}
            </li>
            <li class="nav-item">
                <a href="{{ route('intake.index') }}" class="nav-link"><i
                        class="flaticon-maths-class-materials-cross-of-a-pencil-and-a-ruler"></i><span>Intake</span></a>
            </li>
            <li class="nav-item">
                <a href="{{ route('batch.index') }}" class="nav-link"><i
                        class="flaticon-maths-class-materials-cross-of-a-pencil-and-a-ruler"></i><span>Batch</span></a>
            </li>

            <li class="nav-item">
                <a href="{{ route('module.index') }}" class="nav-link"><i
                        class="flaticon-open-book"></i><span>Module</span></a>
            </li>
            <li class="nav-item">
                <a href="{{ route('subject.index') }}" class="nav-link"><i
                        class="flaticon-open-book"></i><span>Course</span></a>
            </li>
            {{-- <li class="nav-item">
                <a href="{{ route('classRoutine.index') }}" class="nav-link"><i
                        class="flaticon-calendar"></i><span>Class
                        Routine</span></a>
            </li> --}}
            <li class="nav-item">
                <a href="{{ route('participant.index') }}" class="nav-link"><i
                        class="flaticon-classmates"></i><span>Participants</span></a>
                {{-- <ul class="nav sub-group-menu">
                    <li class="nav-item">
                        <a href="" class="nav-link"><i class="fas fa-angle-right"></i>All
                            Participants</a>
                    </li>
                    <li class="nav-item">
                        <a href="student-details.html" class="nav-link"><i class="fas fa-angle-right"></i>Participants
                            Admission</a>
                    </li>
                    <li class="nav-item">
                        <a href="admit-form.html" class="nav-link"><i class="fas fa-angle-right"></i>Form</a>
                    </li>
                    <li class="nav-item">
                        <a href="student-promotion.html" class="nav-link"><i class="fas fa-angle-right"></i>Participants
                            Promotion</a>
                    </li>
                </ul> --}}
            </li>

            <li class="nav-item">
                <a href="{{ route('teacher.index') }}" class="nav-link"><i
                        class="flaticon-multiple-users-silhouette"></i><span>Teachers</span></a>
                <ul class="nav sub-group-menu">
                    <li class="nav-item">
                        <a href="all-teacher.html" class="nav-link"><i class="fas fa-angle-right"></i>All
                            Teachers</a>
                    </li>
                    <li class="nav-item">
                        <a href="teacher-details.html" class="nav-link"><i class="fas fa-angle-right"></i>Teacher
                            Details</a>
                    </li>
                    <li class="nav-item">
                        <a href="add-teacher.html" class="nav-link"><i class="fas fa-angle-right"></i>Add
                            Teacher</a>
                    </li>
                    <li class="nav-item">
                        <a href="teacher-payment.html" class="nav-link"><i class="fas fa-angle-right"></i>Payment</a>
                    </li>
                </ul>
            </li>
            <li class="nav-item">
                <a href="http://localhost/laravel/seip/routine/routine.php" class="nav-link"><i
                        class="flaticon-script"></i><span>Routine</span></a>
            </li>
            <li class="nav-item">
                <a href="http://localhost/laravel/seip/attendance/" class="nav-link"><i
                        class="flaticon-checklist"></i><span>Attendence</span></a>
            </li>
            <li class="nav-item ">
                <a href="{{ route('mark.index') }}" class="nav-link"><i
                        class="flaticon-shopping-list"></i><span>Participant Marks</span></a>
                <ul class="nav sub-group-menu">
                    <li class="nav-item">
                        <a href="exam-schedule.html" class="nav-link"><i class="fas fa-angle-right"></i>Exam
                            Schedule</a>
                    </li>
                    <li class="nav-item">
                        <a href="exam-grade.html" class="nav-link"><i class="fas fa-angle-right"></i>Exam
                            Grades</a>
                    </li>
                </ul>
            </li>

            <li class="nav-item">
                <a href="{{ route('notice.index') }}" class="nav-link"><i
                        class="flaticon-chat"></i><span>Notice</span></a>
            </li>
            {{-- <li class="nav-item">
                <a href="{{ route('masseage.index') }}" class="nav-link"><i class="flaticon-chat"></i><span>Messeage</span></a>
            </li> --}}
            {{-- <li class="nav-item">
                <a href="account-settings.html" class="nav-link"><i class="flaticon-technological"></i><span>Self
                        Profile</span></a>
                <ul class="nav sub-group-menu">
                    <li class="nav-item">
                        <a href="all-fees.html" class="nav-link"><i class="fas fa-angle-right"></i>All Fees
                            Collection</a>
                    </li>
                    <li class="nav-item">
                        <a href="all-expense.html" class="nav-link"><i class="fas fa-angle-right"></i>Expenses</a>
                    </li>
                    <li class="nav-item">
                        <a href="add-expense.html" class="nav-link"><i class="fas fa-angle-right"></i>Add
                            Expenses</a>
                    </li>
                </ul>
            </li> --}}
        </ul>
    </div>
</div>
