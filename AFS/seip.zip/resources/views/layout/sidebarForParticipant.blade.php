<!-- Sidebar Area Start Here -->
<div class="sidebar-main sidebar-menu-one sidebar-expand-md sidebar-color">
    <div class="mobile-sidebar-header d-md-none">
        <div class="header-logo">
            <a href="#">
                <img src="{{ URL::asset('/image/seip-logo.png') }}" alt="seip logo" height="35" width="90">
                <img src="{{ URL::asset('/image/iba.png') }}" alt="du iba logo" height="35" width="90">
            </a>
        </div>
    </div>
    <div class="sidebar-menu-content">
        <ul class="nav nav-sidebar-menu sidebar-toggle-view">
            <li class="nav-item">
                <a href="#" class="nav-link"><i class="flaticon-dashboard"></i><span>Dashboard</span></a>
            </li>
        </ul>
    </div>
</div>
