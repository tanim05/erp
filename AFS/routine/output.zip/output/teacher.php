<!DOCTYPE html>
<html>
<head>
	<title>show Routine</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<body>
	<?php 
	//include 'dbconfig.php';

$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "routine";
$connect = mysqli_connect($hostname, $username, $password, $dbname);
$semester= 'iot_1st';

if(!$connect)
{ 
 	die('Could not connect: ' . mysql_error()); 
} 
mysqli_select_db($connect,"routine");


    $query = "SELECT DISTINCT `$semester`.sub_code, `$semester`.room_no, `$semester`.day,`$semester`.ctime,`teacher`.teacher_name FROM `$semester` JOIN `teacher` ON `$semester`.teacher_id=`teacher`.teacher_id ORDER BY
    `$semester`.day DESC ,`$semester`.ctime DESC";

    $result=mysqli_query($connect, $query);

        $sroutine = "";
        while($row = mysqli_fetch_array($result))
        {
        	// $day = $sroutine.$row['day'];
         //    $ctime = $sroutine.$row['ctime'];
         //    $sub_code = $sroutine.$row['sub_code'];
         //    $teacher_name = $sroutine.$row['teacher_name'];
         //    $room_no = $sroutine.$row['room_no'];
		//echo "$day<br>$ctime<br>$sub_code<br>$teacher_name<br>$room_no<br>";
          
          // echo $row['day']."<br>";
          // echo $row['ctime']."<br>";
          // echo $row['sub_code']."<br>";
          // echo $row['teacher_name']."<br>";
          // echo $row['room_no']."<br>";

            $sroutine = $sroutine."<option>$row[day]</option>";
            $sroutine = $sroutine."<option>$row[ctime]</option>";
            $sroutine = $sroutine."<option>$row[sub_code]</option>";
            $sroutine = $sroutine."<option>$row[teacher_name]</option>";
            $sroutine = $sroutine."<option>$row[room_no]</option>";

            
        }
    // echo '<pre>';
   	 print_r($sroutine);

   	 //print_r($sroutine);
    // var_dump($sroutine);
    // echo '</pre>';
    // exit();

	?>
	<div class="container">
		<div class="row">
			<div class="col-sm-6">
				<h1>Routine for <span>IOT 1st Semester</span></h1>
			</div>
			<div class="col-sm-6">
				<h1><button class="btn btn-success">Download</button></h1>
			</div>	
		</div>
	</div>

	<div class="row">
		<div class="col-sm-12">
			<div class="table">
				<table class="table table-bordered">
				  <thead>
				    <tr>
				      <th scope="col">Time/Week Days</th>
				      <?php $t8 = "8:00-9:00"; ?>
				      <th scope="col"><?php echo $t8; ?></th>
				      <?php $t9 = "9:00-10:00"; ?>
				      <th scope="col"><?php echo $t9; ?></th>
				      <?php $t10 = "10:00-11:00"; ?>
				      <th scope="col"><?php echo $t10; ?></th>
				      <?php $t11 = "11:00-12:00"; ?>
				      <th scope="col"><?php echo $t11; ?></th>
				      <?php $t12 = "12:00-13:00"; 
				      if ($t12!="") { ?>
				      	<th scope="col"><?php echo $t12; ?></th><?php
				      }
				      ?>
				      <?php $t13 = "13:00-14:00"; ?>
				      <th scope="col"><?php echo $t13; ?></th>
				      <?php $t14 = "14:00-15:00"; ?>
				      <th scope="col"><?php echo $t14; ?></th>
				      <?php $t15 = "15:00-16:00"; ?>
				      <th scope="col"><?php echo $t15; ?></th>
				      <?php $t16 = "16:00-17:00"; ?>
				      <th scope="col"><?php echo $t16; ?></th>
				    </tr>
				  </thead>
				  <tbody>
				    <tr>
				      <th scope="row">Sater<br>Day</th>
				      <?php
			
				      	$sub_code108 = "IOT-111";
				      	$Teacher_name108 = "Teacher";
				     	$room_No108 = "Room 303";	

				      
				      $sub_code109 = "IOT-111";
				      $Teacher_name109 = "Teacher Name";
				      $room_No109 = "Room 303";
				      $sub_code110 = "IOT-111";
				      $Teacher_name110 = "Teacher Name";
				      $room_No110 = "Room 303";
				      $sub_code111 = "IOT-111";
				      $Teacher_name111 = "Teacher Name";
				      $room_No111 = "Room 303";
				      $sub_code112 = "IOT-111";
				      $Teacher_name112 = "Teacher Name";
				      $room_No112 = "Room 303";
				      $sub_code113 = "IOT-111";
				      $Teacher_name113 = "Teacher Name";
				      $room_No113 = "Room 303";
				      $sub_code114 = "IOT-111";
				      $Teacher_name114 = "Teacher Name";
				      $room_No114 = "Room 303";
				      $sub_code115 = "IOT-111";
				      $Teacher_name115 = "Teacher Name";
				      $room_No115 = "Room 303";
				      $sub_code116 = "IOT-111";
				      $Teacher_name116 = "Teacher Name";
				      $room_No116 = "Room 303";

				      ?>
				      <th scope="col"><?php echo $sub_code108."<br> ".$Teacher_name108."<br> ".$room_No108; ?></th>
				      <th scope="col"><?php echo $sub_code109."<br> ".$Teacher_name109."<br> ".$room_No109; ?></th>
				      <th scope="col"><?php echo $sub_code110."<br> ".$Teacher_name110."<br> ".$room_No110; ?></th>
				      <th scope="col"><?php echo $sub_code111."<br> ".$Teacher_name111."<br> ".$room_No111; ?></th>
				      <th scope="col"><?php echo $sub_code112."<br> ".$Teacher_name112."<br> ".$room_No112; ?></th>
				      <th scope="col"><?php echo $sub_code113."<br> ".$Teacher_name113."<br> ".$room_No113; ?></th>
				      <th scope="col"><?php echo $sub_code114."<br> ".$Teacher_name114."<br> ".$room_No114; ?></th>
				      <th scope="col"><?php echo $sub_code115."<br> ".$Teacher_name115."<br> ".$room_No115; ?></th>
				      <th scope="col"><?php echo $sub_code116."<br> ".$Teacher_name116."<br> ".$room_No116; ?></th>
				    </tr>
				    <tr>
				    <th scope="row">Sun<br>Day</th>
				    <?php
                      $sub_code208 = "IOT-211";
                      $Teacher_name208 = "Teacher Name";
                      $room_No208 = "Room 303";
                      $sub_code209 = "IOT-211";
                      $Teacher_name209 = "Teacher Name";
                      $room_No209 = "Room 303";
                      $sub_code210 = "IOT-211";
                      $Teacher_name210 = "Teacher Name";
                      $room_No210 = "Room 303";
                      $sub_code211 = "IOT-211";
                      $Teacher_name211 = "Teacher Name";
                      $room_No211 = "Room 303";
                      $sub_code212 = "IOT-211";
                      $Teacher_name212 = "Teacher Name";
                      $room_No212 = "Room 303";
                      $sub_code213 = "IOT-211";
                      $Teacher_name213 = "Teacher Name";
                      $room_No213 = "Room 303";
                      $sub_code214 = "IOT-211";
                      $Teacher_name214 = "Teacher Name";
                      $room_No214 = "Room 303";
                      $sub_code215 = "IOT-211";
                      $Teacher_name215 = "Teacher Name";
                      $room_No215 = "Room 303";
                      $sub_code216 = "IOT-211";
                      $Teacher_name216 = "Teacher Name";
                      $room_No216 = "Room 303";

                      ?>
                      <th scope="col"><?php echo $sub_code208."<br> ".$Teacher_name208."<br> ".$room_No208; ?></th>
                      <th scope="col"><?php echo $sub_code209."<br> ".$Teacher_name209."<br> ".$room_No209; ?></th>
                      <th scope="col"><?php echo $sub_code210."<br> ".$Teacher_name210."<br> ".$room_No210; ?></th>
                      <th scope="col"><?php echo $sub_code211."<br> ".$Teacher_name211."<br> ".$room_No211; ?></th>
                      <th scope="col"><?php echo $sub_code212."<br> ".$Teacher_name212."<br> ".$room_No212; ?></th>
                      <th scope="col"><?php echo $sub_code213."<br> ".$Teacher_name213."<br> ".$room_No213; ?></th>
                      <th scope="col"><?php echo $sub_code214."<br> ".$Teacher_name214."<br> ".$room_No214; ?></th>
                      <th scope="col"><?php echo $sub_code215."<br> ".$Teacher_name215."<br> ".$room_No215; ?></th>
                      <th scope="col"><?php echo $sub_code216."<br> ".$Teacher_name216."<br> ".$room_No216; ?></th>
                    </tr>

				    <tr>
				      <th scope="row">Mon<br>Day</th>
				      <?php
                      $sub_code308 = "IOT-311";
                      $Teacher_name308 = "Teacher Name";
                      $room_No308 = "Room 303";
                      $sub_code309 = "IOT-311";
                      $Teacher_name309 = "Teacher Name";
                      $room_No309 = "Room 303";
                      $sub_code310 = "IOT-311";
                      $Teacher_name310 = "Teacher Name";
                      $room_No310 = "Room 303";
                      $sub_code311 = "IOT-311";
                      $Teacher_name311 = "Teacher Name";
                      $room_No311 = "Room 303";
                      $sub_code312 = "IOT-311";
                      $Teacher_name312 = "Teacher Name";
                      $room_No312 = "Room 303";
                      $sub_code313 = "IOT-311";
                      $Teacher_name313 = "Teacher Name";
                      $room_No313 = "Room 303";
                      $sub_code314 = "IOT-311";
                      $Teacher_name314 = "Teacher Name";
                      $room_No314 = "Room 303";
                      $sub_code315 = "IOT-311";
                      $Teacher_name315 = "Teacher Name";
                      $room_No315 = "Room 303";
                      $sub_code316 = "IOT-311";
                      $Teacher_name316 = "Teacher Name";
                      $room_No316 = "Room 303";

                      ?>
                      <th scope="col"><?php echo $sub_code308."<br> ".$Teacher_name308."<br> ".$room_No308; ?></th>
                      <th scope="col"><?php echo $sub_code309."<br> ".$Teacher_name309."<br> ".$room_No309; ?></th>
                      <th scope="col"><?php echo $sub_code310."<br> ".$Teacher_name310."<br> ".$room_No310; ?></th>
                      <th scope="col"><?php echo $sub_code311."<br> ".$Teacher_name311."<br> ".$room_No311; ?></th>
                      <th scope="col"><?php echo $sub_code312."<br> ".$Teacher_name312."<br> ".$room_No312; ?></th>
                      <th scope="col"><?php echo $sub_code313."<br> ".$Teacher_name313."<br> ".$room_No313; ?></th>
                      <th scope="col"><?php echo $sub_code314."<br> ".$Teacher_name314."<br> ".$room_No314; ?></th>
                      <th scope="col"><?php echo $sub_code315."<br> ".$Teacher_name315."<br> ".$room_No315; ?></th>
                      <th scope="col"><?php echo $sub_code316."<br> ".$Teacher_name316."<br> ".$room_No316; ?></th>
                    </tr>
				      
				    <tr>
				      <th scope="row">Tues<br>Day</th>
				      <?php
                      $sub_code408 = "IOT-411";
                      $Teacher_name408 = "Teacher Name";
                      $room_No408 = "Room 303";
                      $sub_code409 = "IOT-411";
                      $Teacher_name409 = "Teacher Name";
                      $room_No409 = "Room 303";
                      $sub_code410 = "IOT-411";
                      $Teacher_name410 = "Teacher Name";
                      $room_No410 = "Room 303";
                      $sub_code411 = "IOT-411";
                      $Teacher_name411 = "Teacher Name";
                      $room_No411 = "Room 303";
                      $sub_code412 = "IOT-411";
                      $Teacher_name412 = "Teacher Name";
                      $room_No412 = "Room 303";
                      $sub_code413 = "IOT-411";
                      $Teacher_name413 = "Teacher Name";
                      $room_No413 = "Room 303";
                      $sub_code414 = "IOT-411";
                      $Teacher_name414 = "Teacher Name";
                      $room_No414 = "Room 303";
                      $sub_code415 = "IOT-411";
                      $Teacher_name415 = "Teacher Name";
                      $room_No415 = "Room 303";
                      $sub_code416 = "IOT-411";
                      $Teacher_name416 = "Teacher Name";
                      $room_No416 = "Room 303";

                      ?>
                      <th scope="col"><?php echo $sub_code408."<br> ".$Teacher_name408."<br> ".$room_No408; ?></th>
                      <th scope="col"><?php echo $sub_code409."<br> ".$Teacher_name409."<br> ".$room_No409; ?></th>
                      <th scope="col"><?php echo $sub_code410."<br> ".$Teacher_name410."<br> ".$room_No410; ?></th>
                      <th scope="col"><?php echo $sub_code411."<br> ".$Teacher_name411."<br> ".$room_No411; ?></th>
                      <th scope="col"><?php echo $sub_code412."<br> ".$Teacher_name412."<br> ".$room_No412; ?></th>
                      <th scope="col"><?php echo $sub_code413."<br> ".$Teacher_name413."<br> ".$room_No413; ?></th>
                      <th scope="col"><?php echo $sub_code414."<br> ".$Teacher_name414."<br> ".$room_No414; ?></th>
                      <th scope="col"><?php echo $sub_code415."<br> ".$Teacher_name415."<br> ".$room_No415; ?></th>
                      <th scope="col"><?php echo $sub_code416."<br> ".$Teacher_name416."<br> ".$room_No416; ?></th>
                    </tr>
				    <tr>
				      <th scope="row">Wednes<br>Day</th>
				      <?php
                      $sub_code508 = "IOT-511";
                      $Teacher_name508 = "Teacher Name";
                      $room_No508 = "Room 303";
                      $sub_code509 = "IOT-511";
                      $Teacher_name509 = "Teacher Name";
                      $room_No509 = "Room 303";
                      $sub_code510 = "IOT-511";
                      $Teacher_name510 = "Teacher Name";
                      $room_No510 = "Room 303";
                      $sub_code511 = "IOT-511";
                      $Teacher_name511 = "Teacher Name";
                      $room_No511 = "Room 303";
                      $sub_code512 = "IOT-511";
                      $Teacher_name512 = "Teacher Name";
                      $room_No512 = "Room 303";
                      $sub_code513 = "IOT-511";
                      $Teacher_name513 = "Teacher Name";
                      $room_No513 = "Room 303";
                      $sub_code514 = "IOT-511";
                      $Teacher_name514 = "Teacher Name";
                      $room_No514 = "Room 303";
                      $sub_code515 = "IOT-511";
                      $Teacher_name515 = "Teacher Name";
                      $room_No515 = "Room 303";
                      $sub_code516 = "IOT-511";
                      $Teacher_name516 = "Teacher Name";
                      $room_No516 = "Room 303";

                      ?>
                      <th scope="col"><?php echo $sub_code508."<br> ".$Teacher_name508."<br> ".$room_No508; ?></th>
                      <th scope="col"><?php echo $sub_code509."<br> ".$Teacher_name509."<br> ".$room_No509; ?></th>
                      <th scope="col"><?php echo $sub_code510."<br> ".$Teacher_name510."<br> ".$room_No510; ?></th>
                      <th scope="col"><?php echo $sub_code511."<br> ".$Teacher_name511."<br> ".$room_No511; ?></th>
                      <th scope="col"><?php echo $sub_code512."<br> ".$Teacher_name512."<br> ".$room_No512; ?></th>
                      <th scope="col"><?php echo $sub_code513."<br> ".$Teacher_name513."<br> ".$room_No513; ?></th>
                      <th scope="col"><?php echo $sub_code514."<br> ".$Teacher_name514."<br> ".$room_No514; ?></th>
                      <th scope="col"><?php echo $sub_code515."<br> ".$Teacher_name515."<br> ".$room_No515; ?></th>
                      <th scope="col"><?php echo $sub_code516."<br> ".$Teacher_name516."<br> ".$room_No516; ?></th>
                    </tr>
				    <tr>
				      <th scope="row">Thrus<br>Day</th>
				      <?php
                      $sub_code608 = "IOT-611";
                      $Teacher_name608 = "Teacher Name";
                      $room_No608 = "Room 303";
                      $sub_code609 = "IOT-611";
                      $Teacher_name609 = "Teacher Name";
                      $room_No609 = "Room 303";
                      $sub_code610 = "IOT-611";
                      $Teacher_name610 = "Teacher Name";
                      $room_No610 = "Room 303";
                      $sub_code611 = "IOT-611";
                      $Teacher_name611 = "Teacher Name";
                      $room_No611 = "Room 303";
                      $sub_code612 = "IOT-611";
                      $Teacher_name612 = "Teacher Name";
                      $room_No612 = "Room 303";
                      $sub_code613 = "IOT-611";
                      $Teacher_name613 = "Teacher Name";
                      $room_No613 = "Room 303";
                      $sub_code614 = "IOT-611";
                      $Teacher_name614 = "Teacher Name";
                      $room_No614 = "Room 303";
                      $sub_code615 = "IOT-611";
                      $Teacher_name615 = "Teacher Name";
                      $room_No615 = "Room 303";
                      $sub_code616 = "IOT-611";
                      $Teacher_name616 = "Teacher Name";
                      $room_No616 = "Room 303";

                      ?>
                      <th scope="col"><?php echo $sub_code608."<br> ".$Teacher_name608."<br> ".$room_No608; ?></th>
                      <th scope="col"><?php echo $sub_code609."<br> ".$Teacher_name609."<br> ".$room_No609; ?></th>
                      <th scope="col"><?php echo $sub_code610."<br> ".$Teacher_name610."<br> ".$room_No610; ?></th>
                      <th scope="col"><?php echo $sub_code611."<br> ".$Teacher_name611."<br> ".$room_No611; ?></th>
                      <th scope="col"><?php echo $sub_code612."<br> ".$Teacher_name612."<br> ".$room_No612; ?></th>
                      <th scope="col"><?php echo $sub_code613."<br> ".$Teacher_name613."<br> ".$room_No613; ?></th>
                      <th scope="col"><?php echo $sub_code614."<br> ".$Teacher_name614."<br> ".$room_No614; ?></th>
                      <th scope="col"><?php echo $sub_code615."<br> ".$Teacher_name615."<br> ".$room_No615; ?></th>
                      <th scope="col"><?php echo $sub_code616."<br> ".$Teacher_name616."<br> ".$room_No616; ?></th>
                    </tr>
				      
				  </tbody>
				</table>
			</div>
		</div>
	</div>

</body>
</html>